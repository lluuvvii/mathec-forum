import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './pages/Home';
import Register from './pages/Register';
import Login from './pages/Login';
import Questions from './pages/Questions';
import AddQuestion from './pages/AddQuestion';

const App = () => {
  return (
    <div className="App">
      <BrowserRouter>
      <div>
        <Routes>
          <Route exact path="/" element={<Home/>}></Route>
          <Route path="/register" element={<Register/>}></Route>
          <Route path="/login" element={<Login/>}></Route>
          <Route path="/questions" element={<Questions/>}></Route>
          <Route path="/addquestion" element={<AddQuestion/>}></Route>
        </Routes>
      </div>
      </BrowserRouter>
    </div>
  );
}

export default App

const Users = () => {

  return (
    <div><h1>this is users page</h1></div>
  )
}

export default Users
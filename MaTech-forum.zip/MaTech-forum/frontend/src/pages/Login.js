import { useState } from 'react'
import logo from '../images/logo.jpg'

const Login = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    const login = async (email, password) => {
      const response = await fetch('http://localhost:3000/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      })
      const json = await response.json()
      if (response.ok) {
        localStorage.setItem('user', JSON.stringify(json))
      }
      console.log(json)
    }
    await login(email, password)
    console.log(email, password)
  }

  return (
    <div className="container">
      <div className="bagian-kiri">
        <form className='formLogin' onSubmit={e => handleSubmit(e)}>
          <div className='logo'><img src={logo} alt="" /></div>
          <p>Tingkatkan kualitas diskusi dengan Fakultas Matematika dan Ilmu Komputer UNUGHA CILACAP: Bersama-sama kita belajar, berbagi, dan berkembang dalam dunia teknologi informasi dan komunikasi.</p>
          <h2>Login</h2>
          <label>Email</label>
          <input name='email' type='email' placeholder='Masukkan email Anda' onChange={e => setEmail(e.target.value)} value={email} />
          <label>Password</label>
          <input name='Password' type='password' placeholder='Masukkan password Anda' onChange={e => setPassword(e.target.value)} value={password} />
          <div className="BoxText">
            <span>Remember Me</span>
            <span>Forget Password?</span>
          </div>
          <button>Login</button>
          <span> Dont have an account?<a href='/register'>Register</a></span>

        </form>
      </div>
      <div className="bagian-kanan">
      </div>
    </div>
  )
}

export default Login
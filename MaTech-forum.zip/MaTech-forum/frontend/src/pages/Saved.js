const Saved = () => {

  return (
    <div><h1>this is saved page</h1></div>
  )
}

export default Saved
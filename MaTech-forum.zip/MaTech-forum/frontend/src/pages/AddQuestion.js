import { useEffect, useState } from 'react'
import ReactQuill from 'react-quill'
import 'quill/dist/quill.snow.css'
import Navbar from '../components/Navbar'
import TagsInput from 'react-tagsinput'
import 'react-tagsinput/react-tagsinput.css'

const AddQuestion = () => {
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [selected, setSelected] = useState([])

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'))
    const token = user.data.token
    console.log(token)
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()

    const user = JSON.parse(localStorage.getItem('user'))

    if(user){
      const question = { tags: selected, title, body, user_id: user.data.user_id }
      const response = await fetch('/api/questions', {
        method: 'POST',
        body: JSON.stringify(question),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.data.token}`
        }
      })
      const json = await response.json()
      console.log(json)
    }

  }

  return (
    <div style={{ backgroundColor: "#dcdcdc" }}>
      <Navbar />
      <div className="row mt-4 px-5 justify-content-center">
        <div className="col-md-6">
          <div className="card" >
            <div className="card-body px-5">
              <form className="formQuestion" onSubmit={e => handleSubmit(e)} >
                {/* <input type="text" /> */}
                <label htmlFor="">Judul</label>
                <input type="text" placeholder="Title" style={{ borderRadius: "5px", width: "100%" }} onChange={e => setTitle(e.target.value)} value={title} className='mb-3' />
                {/* Tag Input */}
                <label htmlFor="">Tag</label>
                <TagsInput value={selected} onChange={setSelected}/>
                <label htmlFor="" className='mt-3'>Isi</label>
                <ReactQuill
                
                  value={body}
                  onChange={(value) => setBody(value)}
                  modules={{
                    toolbar: [
                      [{ 'size': ['small', false, 'large', 'huge'] }],   // custom dropdown
                      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
                      [{ 'font': [] }],
                      ['bold', 'italic', 'underline', 'strike'],         // toggled buttons
                      ['blockquote', 'code-block'],
                      [{ 'header': 1 }, { 'header': 2 }],                // custom button values
                      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                      [{ 'script': 'sub' }, { 'script': 'super' }],      // superscript/subscript
                      [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
                      [{ 'align': [] }, { 'direction': 'rtl' }, { 'color': [] }, { 'background': [] }], // text direction // dropdown with defaults from theme
                      ['link', 'image', 'video'],
                      ['clean']
                    ],
                  }}
                  theme="snow"
                  style={{ height: "300px" }}
                />
                <button style={{ width: "100px", marginTop: "80px", borderRadius: "10px", border: "none" }}>Send</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AddQuestion

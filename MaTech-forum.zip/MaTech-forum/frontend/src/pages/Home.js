// import { FaBeer } from 'react-icons/fa'
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
// import Nofriani from '../images/Nofriani.jpg'
// import downOutlineIcon from '../images/chevron-down-outline.svg'
import chatBubbleIcon from '../images/chatbubble-outline.svg'
import homeIcon from '../images/home-outline.svg'
import personCircleIcon from '../images/person-circle-outline.svg'
import hashtag from '../images/hashtag.svg'
// import bookmarkIcon from '../images/bookmark-outline.svg'
// import logo from '../images/logo.jpg'
// import likeIcon from '../images/like.svg'
// import dislikeIcon from '../images/dislike.svg'
// import chatIcon from '../images/chat.svg'
// import shareIcon from '../images/share.svg'
import savePostIcon from '../images/savePost.svg'
import Navbar from '../components/Navbar'
// import LineIcon from '../images/Line.svg'
import QuestionsData from '../components/QuestionsData'

const Home = () => {
  const [data, setData] = useState()

  // useEffect(() => {
  //   const user = JSON.getItem
  // })

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch('/api/home/all', {
        headers: {
          'Authorization': `Bearer ${'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMSIsImlhdCI6MTY5NjQwMTk5OH0.IYDrM0LlLU5rjUR4nuN77bP1Bj9m7gKHXSBf8R94nbQ'}`
        }
      })
      const json = await response.json()

      setData(json)
      console.log(json)
    }
    fetchData()
  }, [])

  console.log(data)

  return (
    // <div className="beranda">
    //   <div className="add-argumant">
    //     <div className="overlap-group">
    //       <div className="text-wrapper">Add a new question</div>
    //       <div className="overlap">
    //         <div className="div">+</div>
    //       </div>
    //     </div>
    //   </div>
    //   <div className="right-bar">
    //     <div className="div-wrapper">
    //       <div className="text-wrapper-2">Hot News</div>
    //     </div>
    //   </div>
    //   <div className="overlap-2">
    //     <div className="postingan">
    //       <div className="overlap-3">
    //         <div className="overlap-4">
    //           <div className="text-wrapper-3">Ask 2 mins ago</div>
    //           <div className="text-wrapper-4">2k views</div>
    //           <div className="text-wrapper-5">2 Answer</div>
    //           <div className="tag">
    //             <div className="group">
    //               <div className="overlap-group-2">
    //                 <div className="text-wrapper-6">#JavaScript</div>
    //               </div>
    //             </div>
    //             <div className="overlap-wrapper">
    //               <div className="overlap-5">
    //                 <div className="text-wrapper-7">#JQuery</div>
    //               </div>
    //             </div>
    //           </div>
    //           <p>
    //             Kode jQuery dari halaman sebelumnya (Beranda) memengaruhi halaman baru (halaman Postingan) yang dinavigasi dan menyebabkan kesalahan
    //           </p>
    //           <div className="response">
    //             <img className="fa-solid-comments" alt="Fa solid comments" src={chatIcon} />
    //             <img className="bxs-dislike" alt="Bxs dislike" src={dislikeIcon} />
    //             <div className="text-wrapper-8">14</div>
    //             <img className="vector" alt="Vector" src={likeIcon} />
    //             <img className="frame" alt="Frame" src={shareIcon} />
    //           </div>
    //         </div>
    //         <div className="text-wrapper-9">Kesalahan jQuery</div>
    //         <div className="text-wrapper-10">29 Februari 2026</div>
    //       </div>
    //     </div>
    //     <img className="icon-bookmark" alt="Icon bookmark" src={savePostIcon} />
    //     {/* <img className="image" alt="Image" src="image-3.png" /> */}
    //     <div className="text-wrapper-11">Khaerul Anam</div>
    //   </div>
    //   <div className="overlap-6">
    //     <div className="navbar">
    //       <div className="search">
    //         <input className="input" placeholder="Search" type="text" />
    //       </div>
    //       <div className="account">
    //         <img className="mdi-apple-keyboard" alt="Mdi apple keyboard" src={downOutlineIcon} />
    //         <div className="text-wrapper-12">Nofriani</div>
    //       </div>
    //     </div>
    //     <img className="free-sample-by-wix" alt="" src={logo} />
    //     <img className="img" alt="profile" src={Nofriani} />
    //   </div>
    //   <div className="overlap-7">
    //     <div className="left-bar">
    //       <div className="overlap-8">
    //         <div className="text-wrapper-13">Saved</div>
    //         <div className="text-wrapper-14">Tag</div>
    //         <div className="text-wrapper-15">Home</div>
    //         <div className="text-wrapper-16"><Link to="/questions">Question</Link></div>
    //         <div className="text-wrapper-17">Users</div>
    //         <img className="icon-home" alt="Icon home" src={homeIcon} />
    //         <img className="icon-bookmark-2" alt="Icon bookmark" src={bookmarkIcon} />
    //         <img className="icon-message-circle" alt="Icon message circle" src={chatBubbleIcon} />
    //         <div className="text-wrapper-18">#</div>
    //       </div>
    //       <div className="overlap-9">
    //         <div className="text-wrapper-19">#JavaScript</div>
    //         <div className="text-wrapper-20">12.3K Questions</div>
    //         <div className="text-wrapper-21">#JQuery</div>
    //         <div className="text-wrapper-22">34.5K Questions</div>
    //         <div className="text-wrapper-23">#Sas</div>
    //         <div className="text-wrapper-24">6.3K Questions</div>
    //         <div className="text-wrapper-25">#Looping</div>
    //         <div className="text-wrapper-26">2.3K Questions</div>
    //         <div className="text-wrapper-27">#Bug</div>
    //         <div className="text-wrapper-28">79.6K Questions</div>
    //         <div className="text-wrapper-29">Popular Tags</div>
    //       </div>
    //     </div>
    //     <img className="icon-user-circle-alt" alt="Icon user circle alt" src={personCircleIcon} />
    //   </div>
    //   <div className="overlap-10">
    //     <div className="overlap-group-wrapper">
    //       <div className="overlap-11">
    //         <div className="overlap-12">
    //           <div className="text-wrapper-30">Ask 2 mins ago</div>
    //           <div className="text-wrapper-31">2k views</div>
    //           <div className="text-wrapper-32">Looping</div>
    //           <div className="text-wrapper-33">29 Februari 2026</div>
    //         </div>
    //         <div className="overlap-13">
    //           <div className="text-wrapper-34">0 Answer</div>
    //           <div className="response-2">
    //             <img className="fa-solid-comments-2" alt="Fa solid comments" src={chatIcon} />
    //             <img className="bxs-dislike-2" alt="Bxs dislike" src={dislikeIcon} />
    //             <div className="text-wrapper-35">14</div>
    //             <img className="vector-2" alt="Vector" src={likeIcon} />
    //             <img className="frame" alt="Frame" src={shareIcon} />
    //           </div>
    //         </div>
    //         <div className="overlap-14">
    //           <div className="tag-2">
    //             <div className="group-2">
    //               <div className="overlap-group-3">
    //                 <div className="text-wrapper-36">#Looping</div>
    //               </div>
    //             </div>
    //             <div className="group-3">
    //               <div className="overlap-15">
    //                 <div className="text-wrapper-37">#Sas</div>
    //               </div>
    //             </div>
    //           </div>
    //           <p >
    //             Saya berurusan dengan jadwal pembayaran dan memiliki format berikut
    //             Saya perlu menghitung baris terakhir new_outstanding di sas?
    //             dengan menghapus jumlah terutang dari baris sebelumnya
    //             Saya telah melakukan sesuatu seperti itu
    //           </p>
    //         </div>
    //       </div>
    //     </div>
    //     <img className="icon-bookmark-3" alt="Icon bookmark" src={savePostIcon} />
    //     <div className="text-wrapper-38">M. Amrul S</div>
    //     <div className="rectangle-2" />
    //   </div>
    //   <div className="overlap-16">
    //     <div className="text-wrapper-39">Hot</div>
    //     <img className="line" alt="Line" src={LineIcon} />
    //     <div className="text-wrapper-40">Weeks</div>
    //     <div className="text-wrapper-41">Month</div>
    //     <img className="line-2" alt="Line" src={LineIcon} />
    //   </div>
    // </div>
    <div className="container-fluid" style={{ backgroundColor: "#dcdcdc" }}>
      <div className="row">
        <Navbar />
      </div>
      <div className="row mt-4">
        <div className="col-2">
          <div className="card">
            <div className="card-body px-6">
              <div className="d-flex gap-4 flex-column">
                <div className="d-flex gap-2 align-items-center">
                  <img className="icon-home" alt="Icon home" src={homeIcon} style={{ height: "30px" }} />
                  <h5 style={{ marginBottom: "0" }}>Home</h5>

                </div>
                <div className="d-flex gap-2 align-items-center">
                  <img className="icon-home" alt="Icon home" src={chatBubbleIcon} style={{ height: "30px", marginLeft: "2px" }} />
                  <h5 style={{ marginBottom: "0" }}>Question</h5>

                </div>
                <div className="d-flex gap-2 align-items-center">
                  <img className="icon-home" alt="Icon home" src={personCircleIcon} style={{ height: "30px", marginLeft: "4px" }} />
                  <h5 style={{ marginBottom: "0" }}>Users</h5>

                </div>
                <div className="d-flex gap-2 align-items-center">
                  <img className="icon-home" alt="Icon home" src={hashtag} style={{ height: "30px", marginLeft: "6px" }} />
                  <h5 style={{ marginBottom: "0" }}>Tag</h5>

                </div>
                <div className="d-flex gap-3 align-items-center">
                  <img className="icon-home" alt="Icon home" src={savePostIcon} style={{ height: "30px", marginLeft: "10px" }} />
                  <h5 style={{ marginBottom: "0" }}>Saved</h5>

                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-8 px-5">
          <div>
            <div className="alert alert-success">
              <div className="d-flex justify-content-between align-items-center">
                Add new question
                <Link to='/addquestion' className='btn btn-light'>+</Link>
              </div>
            </div>
          </div>
          {/* Content */}
          {data && data.data.map((question) => (
            <QuestionsData key={question.user_id} question={question} />
          ))}
        </div>
        {/* End Content */}
        <div className="col-2">
          <div className="card">
            <div className="card-body px-5">
              <div className="d-flex gap-4 flex-column">
                <h5>Hot News</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
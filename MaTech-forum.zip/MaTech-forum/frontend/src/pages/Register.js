import { useEffect, useState } from 'react'
import logo from '../images/logo.jpg'

const Register = () => {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    const register = async (name, email, password) => {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      })
      const json = await response.json()
      console.log(json)
    }
    await register(name, email, password)
    console.log(name, email, password)


  }

  return (
    <div className="container">
      <div className="bagian-kiri">
        <form className='formRegister' onSubmit={e => handleSubmit(e)}>
          <div className='logo'>
            <img className="logoPict" src={logo} alt="logo" />
          </div>
          <p>Tingkatkan kualitas diskusi dengan Fakultas Matematika dan Ilmu Komputer UNUGHA CILACAP: Bersama-sama kita belajar, berbagi, dan berkembang dalam dunia teknologi informasi dan komunikasi.</p>
          <h2>Register</h2>
          <label>Username</label>
          <input name='name' type='name' placeholder='Masukan username' onChange={e => setName(e.target.value)} value={name} />
          <label>Email</label>
          <input name='email' type='email' placeholder='Masukkan email Anda' onChange={e => setEmail(e.target.value)} value={email} />
          <label>Password</label>
          <input name='password' type='password' placeholder='Masukkan password Anda' onChange={e => setPassword(e.target.value)} value={password} />
          <label>Confirm Password</label>
          <input name='password' type='password' placeholder='Konfirmasi password Anda' onChange={e => setPassword(e.target.value)} value={password} />
          <button>Register</button>
          <span> Already have an account?<a href='/login'>Login</a></span>
        </form>
      </div>
      <div className="bagian-kanan">
      </div>
    </div>
  )
}

export default Register
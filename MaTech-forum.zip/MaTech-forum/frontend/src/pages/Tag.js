const Tag = () => {

  return (
    <div><h1>this is tag page</h1></div>
  )
}

export default Tag
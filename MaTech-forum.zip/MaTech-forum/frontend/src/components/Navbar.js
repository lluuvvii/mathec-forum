import logo from '../images/logo.jpg'
import Nofriani from '../images/Nofriani.jpg'
import downOutline from '../images/chevron-down-outline.svg'

const Navbar = () => {
  return (
    <nav class="navbar navbar-expand-lg" style={{backgroundColor: "#ffffff"}}>
      <div class="container-fluid">
        <div className="col-2">
          <img className="free-sample-by-wix" alt="" src={logo} style={{ marginLeft: "30px", width: "80px" }} />
        </div>
        <div className="col-8">
          <div className="navbar">
            <div className="search">
              <input className="input" placeholder="Search" type="text" />
            </div>
          </div>
        </div>
        <div className="col-2 d-flex" style={{marginLeft: "50px", alignItems: "center"}}>
          <img className="profile" src={Nofriani} alt=""
          style={{ marginRight: "20px", width: "50px", height: "50px", borderRadius: "50%", objectFit: "cover"}} />
          <div className="text">
          <h5>Nofriani</h5>
          </div>
          <div className="img">
          <img src={downOutline} alt="" style={{height: "30px", marginLeft: "10px"}}/>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
import chatIcon from '../images/chat.svg'
import likeIcon from '../images/like.svg'
import dislikeIcon from '../images/dislike.svg'


const QuestionsData = ({question}) => {
  return (
    <div className="card mb-4">
    <div className="card-body">
      <div className="d-flex gap-3  p-3">
        <div className="">
          <img style={{ width: "50px", borderRadius: "50%" }} src={question.profile_picture === null ? 'https://atmos.ucla.edu/wp-content/themes/aos-child-theme/images/generic-avatar.png' : question.profile_picture} alt="" />
        </div>
        <div className="">
          <h5>{question.title}</h5>
          <div className='d-flex'>
            <div>
              {question.uploader}
            </div>
            <div>
              {question.posted_at}
            </div>
          </div>
          <div className='d-flex'>
            <div>
              {question.viewer_total} views
            </div>
            <div>
              {question.posted_at}
            </div>
          </div>
          <div className="d-flex gap-2 mt-2">
            {question.tags && question.tags.map((tag) => (
              <button className="btn btn-outline-primary text-capitalize">{tag.tag_name}</button>
            ))}
          </div>
          <div className='mt-4'>
            <p className='text-start'>{question.body}</p>
          </div>
          <div className="mt-4">
            <div className="d-flex gap-3">
              <div className="d-flex gap-1">
                <img src={likeIcon} alt="" />
                {question.like}
              </div>
              <div className="d-flex gap-1">
                <img src={dislikeIcon} alt="" />
                {question.dislike}
              </div>
              <div className="d-flex gap-1">
                <img src={chatIcon} alt="" />
                {question.answer_total} Answers
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  )
}

export default QuestionsData